package userInputInJava;

public class UserInputInJava {

	/** made variables private **/
	
	private String name;
	private int intX;
	private float floatX;
	private char charX;
	
	/** methods to access class variable **/
	
	public int getIntX()
	{
		return intX;
	}
	
	public float getFloatX()
	{
		return floatX;
	}
	
	public char getCharX()
	{
		return charX;
	}
	
	public String getname()
	{
		return name;
	}
	
	/** methods to  set variables  **/

	public void setIntX(int intX)
	{
		this.intX=intX;
	}
	
	public void setFloatX(float floatX)
	{
		this.floatX=floatX;
	}
	
	public void setCharX(char charX)
	{
		this.charX=charX;
	}
	
	public void setname(String name)
	{
		this.name=name;
	}
	
	
}
