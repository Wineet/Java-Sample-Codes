package userInputInJava;

import java.util.Scanner;
 

public class UserInputJavaTester {

	
	public static void main(String[] args) {
		Scanner scan =new Scanner(System.in);
		
	UserInputInJava obj1=new UserInputInJava();	// creating object and referance to class
	System.out.println("Enter Char");
	obj1.setCharX(scan.next().charAt(1));	// Taking USer I/p and storing
	System.out.println("Enter Float");
	obj1.setFloatX(scan.nextFloat());		// Taking USer I/p and storing
	System.out.println("Enter Int");
	obj1.setIntX(scan.nextInt());			// Taking USer I/p and storing
	System.out.println("Enter String");
	obj1.setname(scan.next());
	
	System.out.println("User Char="+obj1.getCharX());
	System.out.println("User Int="+obj1.getIntX());
	System.out.println("User Float="+obj1.getFloatX());
	System.out.println("User String="+obj1.getname());
	}

}
