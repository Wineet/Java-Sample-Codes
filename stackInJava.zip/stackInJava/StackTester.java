package stackInJava;

import java.util.Stack;

public class StackTester {

	
	public static void main(String[] args) {

		Stack stack = new Stack();
		
		stack.push(12);
		stack.push("Vinit");
		stack.push(12.45);
		stack.push('V');
		stack.push(1233);
		stack.push(125.4);
	
		System.out.println(stack.peek());
		System.out.println(stack);
	
		System.out.println("---------");
		while(!stack.empty())
		{
			System.out.println(stack.pop());
		}
	}

}
