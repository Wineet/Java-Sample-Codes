package studentDataBase_arraylist;

public class StudentData {

	private String name;
	private double marks;
	private int age;
	
	
	public StudentData() {		// Default Constructor
		super();
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
}
