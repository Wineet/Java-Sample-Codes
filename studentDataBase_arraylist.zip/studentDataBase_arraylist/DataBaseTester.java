package studentDataBase_arraylist;
import java.util.Scanner;

import java.util.ArrayList;

public class DataBaseTester {
	
	
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		ArrayList<StudentData> list = new ArrayList<StudentData>();
		
		Menu menu=new Menu();
		DataBaseTester obj = new DataBaseTester();
		
		while(true){
		 switch(menu.User_menu()) 	// display user menu
		 {
		case 1:
			System.out.println("Welcome>>> Creat New Account Here");
			list.add(menu.newStudentDetails());
			break;
		case 2:
			System.out.println("Displaying All Student Data");
			System.out.println(list);
			menu.allDataDisplay(list);
			
			break;
		case 3:
			System.out.println("Search Option\n Enter Name to search>>");
			String name=scan.next();
			menu.studentSearch(list, name);
			break;
		case 4:
			System.out.println("Search Option\n Enter Name to search>>");
			String nameDel=scan.next();
			int i=menu.studentdelete(list, nameDel);
			list.remove(i);
			break;
		case 5:
			System.out.println("Exit");
			System.exit(0);
			
		default:
			System.out.println("Wrong Choice");
			
		 }
		}

	}

}
