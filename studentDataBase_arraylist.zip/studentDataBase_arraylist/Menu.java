package studentDataBase_arraylist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Menu {
	
	Scanner scan =new Scanner(System.in);
	
	public int User_menu()
	{
		System.out.println("Enter Choice...");
		System.out.println("1.Creat New Student Profile");
		System.out.println("2.Show All Avilable Profile");	
		System.out.println("3.Search for student Profile");	
		System.out.println("4.Delete student Profile");	
		
		//System.out.println("4.Search for student Profile");	
		return scan.nextInt();
	}
	
	public  StudentData newStudentDetails()
	{
		StudentData student =new StudentData();
		System.out.println("Enter Name->");
		student.setName(scan.next());
		
		System.out.println("Enter Age->");
		student.setAge(scan.nextInt());
		
		System.out.println("Enter Marks->");
		student.setMarks(scan.nextDouble());
		return student;
	}
	
	public void allDataDisplay(ArrayList<StudentData> temp)
	{
		Iterator<StudentData> itr = temp.iterator();
		while(itr.hasNext())
		{
			StudentData obj=itr.next();
		    System.out.println(obj.getName());
		    System.out.println(obj.getAge());
		    System.out.println(obj.getMarks());
		    System.out.println("-------------------------");
		}
	}
	
	public void studentSearch(ArrayList<StudentData> temp,String name)
	{
		Iterator<StudentData> itr = temp.iterator();
		while(itr.hasNext())
		{
			StudentData obj=itr.next();
			
		   if(name.equals(obj.getName()))
		   {
			   System.out.println("****** Search Result ******");
			    System.out.println(obj.getName());
			    System.out.println(obj.getAge());
			    System.out.println(obj.getMarks());
			    System.out.println("--------------------------");
		   }
   		}
		
	}
	
	public int studentdelete(ArrayList<StudentData> temp,String name)
	{
		Iterator<StudentData> itr = temp.iterator();
		int i=0;
		while(itr.hasNext())
		{
			StudentData obj=itr.next();
			
		   if(name.equals(obj.getName()))
		   {
			   return i;
		   }
		   i++;
   		}
		return i;
	}
	
}
