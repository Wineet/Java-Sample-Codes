package abstractionInJava;

public class AbstractionTester {

	public static void main(String[] args) {

		//ClassA obj = new ClassA(); //can't creat object of abstract Class
		
		ClassB obj1 = new ClassB();
		obj1.fun();
	}

}
