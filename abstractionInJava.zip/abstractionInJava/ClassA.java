package abstractionInJava;

public abstract class ClassA {
	 int x;
	 String Name;
	public abstract void fun();
	
}
class ClassB extends ClassA{

	public void fun() {
		System.out.println("IN Implement Function");
	}	
	
}
