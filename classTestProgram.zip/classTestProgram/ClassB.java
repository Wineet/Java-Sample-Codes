package classTestProgram;

public class ClassB {
	private String x;

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}
}
