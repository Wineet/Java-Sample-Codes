package classTestProgram;

public class ClassA {
	
private int x;

void setX(int x)
{
	this.x=x;
}
	
public static void main(String[] args) {
	
	ClassA obj=new ClassA();
	ClassB obj2=new ClassB();
	obj.setX(15);
	obj2.setX("Vinit");
	System.out.println("value of X="+obj.x);
	System.out.println(obj2.getX());
}

}
