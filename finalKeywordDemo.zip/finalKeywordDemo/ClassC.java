package finalKeywordDemo;

/**
 * 
 * Final Method Override Demo 
 *
 */


public class ClassC {
	
	final public void print(){				// Final Method	
		System.out.println("IN CLASS C");
	}

}

class ClassD extends ClassC{
	
	/*
	 * overrides finalKeywordDemo.ClassC.print
	- Cannot override the final method from ClassC
	 */
	
	/*
	 * public void print(){				// Produces Error
	 
		System.out.println("IN CLASS D");	
		
	}*/
	
}
