package finalKeywordDemo;

public class FinalTester {

	
	public static void main(String[] args) {
		 ClassA obj = new ClassA("German");	// Assign SUBJECT blank final variable
		
		 // ClassA obj = new ClassA();	// This will produce Error because balnk final keyword is not intialised

		 System.out.println(obj.getName());
		 System.out.println(obj.getSubject());
		
		
		
	}

}
