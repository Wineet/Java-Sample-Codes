package finalKeywordDemo;

public class Waste {

	public void Demo(){
		System.out.println("Vinit");
		
	}
}

class Waste2 extends Waste{
	
	final public void Demo(){				// doesn;t show Error
		System.out.println("Kumar");
	}
	
}

/*
class Waste3 extends Waste2{
	public void Demo()				// produces Error
	{
		
	}
	
}*/