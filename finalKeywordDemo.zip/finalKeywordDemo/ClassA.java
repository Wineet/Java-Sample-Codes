package finalKeywordDemo;

public class ClassA {
	/* Final Key Word Class Demo*/
	
	final String NAME="Vinit";		/*Only once we can assign values*/
	final String SUBJECT;		//If we declare only then Assignment should be done in constructor
	
	
	
	/*public ClassA() {		it will not allow constructor without blank final keyword
		super();
	}*/
	public ClassA(String sUBJECT) {
		super();
		SUBJECT = sUBJECT;
	}

	void setName(String NAME){
		//this.NAME=NAME;			/*The final field ClassA.NAME cannot be assigned*/
	}
	
	public String getName()
	{
		return this.NAME;
	}
	
	public String getSubject()
	{
		return this.SUBJECT;
	}
	
}
