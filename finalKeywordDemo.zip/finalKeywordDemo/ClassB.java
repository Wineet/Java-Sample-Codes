package finalKeywordDemo;

/*final Class  Demo
 * 
 */



public final class ClassB {

	private int x;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}
		
}
/*
 * The type ClassC cannot subclass the final class ClassB (ERROR)
 * 
class ClassC extends ClassB{
	
}


*/
