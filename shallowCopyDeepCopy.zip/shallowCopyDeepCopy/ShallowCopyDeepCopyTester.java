package shallowCopyDeepCopy;

public class ShallowCopyDeepCopyTester {

	public static void main(String[] args) {
		
		ShallowCopyDeepCopy obj1= new ShallowCopyDeepCopy();
		ShallowCopyDeepCopy obj2= new ShallowCopyDeepCopy();
		ShallowCopyDeepCopy obj3= new ShallowCopyDeepCopy();
		
		obj1.setAvg(12.5f);
		obj1.setName("Asmuth");
		obj1.setValue(25);
		
	obj2=obj1;	// Shares Same HAsh Code pointing to Same Referance
					//Same Value And Same HAsh Code
	System.out.println(obj1.hashCode());
	System.out.println(obj2.hashCode());
	
		//**** Deep Copy  ****///
	
		// Same value and Diff Hash code diff memory spaces
	
		obj2.setAvg(obj1.getAvg());
		obj2.setName(obj1.getName());
		obj2.setValue(obj1.getValue());
	
		//** Other way we can use cloning technique**//
		
		System.out.println(obj1.hashCode());
		System.out.println(obj3.hashCode());
	}

}
