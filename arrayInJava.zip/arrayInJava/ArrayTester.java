package arrayInJava;

public class ArrayTester {

	public static void main(String[] args) {
		
		int arr[];	//Normal Integer Type of Array initilize Array Declaration
		arr=new int[15];
		
		for(int i=0;i<arr.length;i++)	// Storing Array
		{
			arr[i]=i;
		}
		
		
		for(int i=0;i<arr.length;i++)		// Displaying array
		{
			System.out.println("arr["+i+"]="+arr[i]);
		}
		
		 ArrayInJava [] objArr;			// Declaration of array of objects
		 objArr = new ArrayInJava[15];	// array of objects intialize
		
		 			/* Intially complete array of object is Null so we need to create 
		 			 * referances of class 
		 			 */
		 
		 for(int i=0;i<objArr.length;i++)	// creating referance of class for complete '
		 {									// array of objects
			 objArr[i]=new ArrayInJava();
			 
		 }
		 
		// objArr[1]= new ArrayInJava();	//Class referance created
		 //objArr[2]= new ArrayInJava();
		
		 objArr[1].setX(12);		
		 objArr[2].setX(15);
		
		System.out.println("objArr[1]="+objArr[1].getX());
		System.out.println("objArr[2]="+objArr[2].getX());
		
	}

}
