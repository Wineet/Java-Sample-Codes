package multi_Level_Inheritance_Interface;

interface  ClassA {

	public abstract void fun1();

}

interface ClassB {
	
	public abstract void fun2();

}

				//Multiple Inheritance 
class ClassC implements ClassA,ClassB{		// ClassC have property of parent ClassA And parent ClassB
	
	public void fun1() {
		System.out.println("In FUn1");
	}
	
	public void fun2() {
		System.out.println("In FUn2");
	}
}
