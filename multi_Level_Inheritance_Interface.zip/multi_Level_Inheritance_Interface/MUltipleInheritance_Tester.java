package multi_Level_Inheritance_Interface;

public class MUltipleInheritance_Tester {

	
	public static void main(String[] args) {
		ClassC obj = new ClassC();
		obj.fun1();		// PArent A property
		obj.fun2();		// Parent B property
	}

}
