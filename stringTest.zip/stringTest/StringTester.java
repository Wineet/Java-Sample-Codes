package stringTest;

public class StringTester {

	
	public static void main(String[] args) {

		String s1="Vinit";
		String s2="vinit";
		s1=s1.concat(" Kumar");
		
		System.out.println(s1);
		
	}

}
