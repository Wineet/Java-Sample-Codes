package interfaceTest;

 interface InterfaceClass {			// Interface Class  100% abstraction

	 final int val=10;				// by default members are static final
	 public abstract void engine();
	 public abstract void color();

}
 
 class Audi implements InterfaceClass{	 			// interface implement Method

	 private String series;
	 
	 
	 //** IMplemented Methods*/
	 
	public void engine() {
		
		System.out.println("Audi Engine");
		
	}

	public void color() {
		System.out.println("Blue Color Audi only");
	
	}
	
	//
	
	public Audi() {			// Default Constructor
		super();
	}

	public Audi(String series) {
		super();
		this.series = series;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	} 
	 
 }
