package interfaceTest;

public class InterfaceTester {

	public static void main(String[] args) {
		Audi audi= new Audi("My Series");
		audi.color();
		audi.engine();
		System.out.println(audi.getSeries());
		
	}
}
