package arrayListDemo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayListTest {

	public static void main(String[] args) {

		ArrayList<String> list =new ArrayList<String>();
		
		list.add("Vinit");
		list.add("MAyur");
		list.add("Asmuth");
		list.add("Alex");
		
		System.out.println(list);				 // Display Complete list
		
		ListIterator<String> obj = list.listIterator();
		
		while(obj.hasNext())
		{
			System.out.println("IN");
			System.out.println(obj.next());
			obj.add("XYZ");
			
		}
		System.out.println(list);
	
		Iterator<String> obj2 = list.iterator();
		
		while(obj2.hasNext())
		{
			System.out.println(obj2.next());
		}
	
	}
	
}



/**Iterator MEthod for traversing**/
/*
Iterator itr =list.iterator();	// Support only >>add<< // >> remove << // >> hasNext << // >> next <<

System.out.println(itr.hasNext());

while(itr.hasNext())					// Iterative method to display list
{
	String string=(String) itr.next();
	System.out.println(string);
										//itr.remove();// remove the object of list
}
*/



/*
//list.set(1, "XYZ");	// Replaces Object
//list.add(1, "XYZ");	// Add Object to perticular position and shifts other data
//list.clear();		    // Clear Complete List
//list.equals("vinit"); // Check weather Object Equal or Not
//	list.remove(1);
// list.remove("Vinit");	// removes Vinit from list and return True if present and removed if not then false
//list.get(1);

System.out.println(list.remove("Vinit"));
System.out.println(list);				// Display Empty list
*/