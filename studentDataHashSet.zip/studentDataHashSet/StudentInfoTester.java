package studentDataHashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class StudentInfoTester {

	
	public static void main(String[] args) {
		
		HashSet<StudentInfo> student = new HashSet<StudentInfo>();
		StudentInfo s1 = new StudentInfo(12, "Vinit");
		StudentInfo s2 = new StudentInfo(14,"Mayur");
		student.add(s1);
		student.add(s2);
		Iterator<StudentInfo> itr = student.iterator();
		while(itr.hasNext())
		{
			StudentInfo s3= itr.next();
			System.out.println(s3.getName());
			System.out.println(s3.getAge());
		}
		
		HashSet<String> string = new HashSet<String>();
		string.add("Vinit");
		string.add("Mayur");
		string.add("Asmuth");
		string.add("Vinit");			// No duplicates are allowed or added in hash set
		System.out.println(string);		

		
		/*
		
		// hashset and array collection//
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("Vinit");
		list.add("Mayur");
		list.add("Asmuth");
		list.add("Mayur");
		System.out.println(list);
		HashSet<String> set = new HashSet(list);	// new HashSet will be created with List content ssme content will be ignored
		set.add("vicky");
		//System.out.println(list);
		Iterator<String> itr = set.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		
		}
		System.out.println(list);
		System.out.println(set);
		*/
	}

}
