package classObjectTest;

public class ObjectTester {

	public static void main(String[] args) {
		DemoClass obj1= new DemoClass();
		DemoClass obj2= new DemoClass();
		
		obj1.setName("Vinit");
		obj1.setX(12);
		System.out.println(obj1.getName());
		System.out.println(obj1.getX());
		System.out.println(obj1.hashCode());
		
		//** Empty Object **////
		
		System.out.println(obj2.getName());		//Null
		System.out.println(obj2.getX());		//Zero
		System.out.println(obj2.hashCode());	// diff HashCode
		
		//** object Copy  **////
		
		obj2=obj1;	 // SHALLOW COPY		// share same ref Now
		
		System.out.println(obj1.getName());
		System.out.println(obj1.getX());
		System.out.println(obj1.hashCode());
		
		System.out.println(obj2.getName());	
		System.out.println(obj2.getX());	
		System.out.println(obj2.hashCode());	//Share sameHash Code now
		
		obj2.setName("Asmuth");
		
		System.out.println(obj1.getName());	// both name changes due to same ref
		System.out.println(obj2.getName());	
		
		
		//**** Object Comparison ***////
		
		obj1.setName("Vinit");
		obj1.setX(12);
		
		obj2.setName("Vinit");
		obj2.setX(12);
		
		System.out.println("obj1#"+obj1.hashCode());
		System.out.println("obj2#"+obj2.hashCode());
		
		if(obj1.getX()==obj2.getX())	// Can Compare with obj data members
		{
			System.out.println("Data Members Comparison Done");
		}
		else
		{
			System.out.println("Can't Compare Data Member");
		}
						
		if(obj1==obj2)      /* Fails At deep copy but TRUE at Shallow COPY*/
		{
			System.out.println("object Comparison Done");
			
		}
		else
		{
			System.out.println("Can't Compare objects of Class");	
			
		}
		
		
	}

}
