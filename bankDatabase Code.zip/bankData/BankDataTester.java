package bankData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BankDataTester {

	
	private static final int Collection = 0;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		AccountAction accountAction = new AccountAction();
		ArrayList<BankData> accList = new ArrayList<>();
		
		while(true)
		{
			switch(accountAction.menu())
			{
			case 1:
				System.out.println("Welcome To creat New Account");
				accList.add(accountAction.newAccount());
				break;
			case 2:
				System.out.println("Display All Acoount Details");
				accountAction.DisplayAllAccountInfo(accList);
				break;
			case 3:
				System.out.println("Welcome to Deposite Money Section");
				System.out.println("Enter Account Number");
				int accNumber=scan.nextInt();
				System.out.println("Enter Balance");
				double money=scan.nextDouble();
				accountAction.depositeMoney(accList, money, accNumber);
				break;
			case 4:
				System.out.println("Welcome to Withdraw Money Section");
				System.out.println("Enter Account Number");
				int accNumber1=scan.nextInt();
				System.out.println("Enter Balance");
				double money1=scan.nextDouble();
				accountAction.withdrawMoney(accList, money1, accNumber1);
				break;
			case 5:
				System.out.println("Sorting On Balance");
				Collections.sort(accList, BankData.balance);
				accountAction.DisplayAllAccountInfo(accList);
				break;
			default:
				System.out.println("Wrong Choice!!! Re-enter..");
			
			}
			
			
			
			
			
		}

	}

}
