package bankData;

import java.util.Comparator;

public class BankData {

	private String name;
	private  int accNumber;
	private double accBalance;
	private static int count=123456;

	public BankData() {
		super();
		this.accNumber=count++;
	}

	public BankData(String name, double accBalance) {
		super();
		this.name = name;
		this.accBalance = accBalance;
		this.accNumber=count++;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAccNumber(int accNumber) {
		this.accNumber=accNumber;
	}
	public int getAccNumber() {
		return accNumber;
	}


	public double getAccBalance() {
		return accBalance;
	}


	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	
public static Comparator<BankData> balance= new Comparator<BankData>(){

	public int compare(BankData b1, BankData b2){
	 double bal1 =b1.getAccBalance();
	 double bal2 =b2.getAccBalance();
		return (int)(bal1-bal2);
	}
	
};
	@Override
	public String toString() {
		return "AccountAction [name=" + name + ", accNumber=" + accNumber
				+ ", accBalance=" + accBalance + "]";
	}

	

}
