package bankData;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;


public class AccountAction {
	static int count=0;
	Scanner scan = new Scanner(System.in);
	
public int menu(){
	System.out.println("Enter a Choice>>>");
	System.out.println("1. Creat New Account");
	System.out.println("2. Display All Account");
	System.out.println("3. Deposite Money  Account");
	System.out.println("4. Withdraw Money  Account");
	System.out.println("Exit");
	return scan.nextInt(); 
}	

public BankData newAccount(){
	
	BankData bankData = new BankData();
	System.out.println("Enter the name of acc. Holder");
	bankData.setName(scan.next());
	System.out.println("Enter Intial Account Balance");
	bankData.setAccBalance(scan.nextDouble());
	System.out.println(bankData.getAccNumber());
	return bankData;
}

public void DisplayAllAccountInfo(ArrayList<BankData> accList){
	
	Iterator<BankData> itr = accList.iterator();
	while(itr.hasNext())
	{
		BankData acc = itr.next();
		System.out.println(acc);
	}
}
	
public void depositeMoney(ArrayList<BankData> accList,double money,int accNumber){
	
	Iterator<BankData> itr = accList.iterator();
	
	while(itr.hasNext())
	{
		BankData acc = itr.next();
		
		if(acc.getAccNumber()==accNumber)
		{
			double prevBal= acc.getAccBalance();
			prevBal=prevBal+ money;
			acc.setAccBalance(prevBal);
			return ;
		}
		
	}
	System.out.println("No MAtch Found");
}


public void withdrawMoney(ArrayList<BankData> accList,double money,int accNumber){
	
	Iterator<BankData> itr = accList.iterator();
	
	while(itr.hasNext())
	{
		BankData acc = itr.next();
		
		if(acc.getAccNumber()==accNumber)
		{
			double prevBal= acc.getAccBalance();
			prevBal=prevBal- money;
			acc.setAccBalance(prevBal);
			return ;
		}
		
	}
	System.out.println("No MAtch Found");
}


}
