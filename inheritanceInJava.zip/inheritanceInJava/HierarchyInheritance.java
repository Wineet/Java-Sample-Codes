package inheritanceInJava;

public class HierarchyInheritance {

	private String name;
	private float weight;
	private int age;
	
	//*** Constructor ***////
	public HierarchyInheritance() {
		super();
	}
	
	//*** constructor with argument **//
	public HierarchyInheritance(String name, float weight, int age) {
		super();
		this.name = name;
		this.weight = weight;
		this.age = age;
	}
	
	//*** Getter and Setter **///
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "HierarchyInheritance [name=" + name + ", weight=" + weight
				+ ", age=" + age + "]";
	}
	
	
	
}

class Person extends HierarchyInheritance{
	private String job;
	private String salary;
	
	//*** Constructors **///
	
	public Person() {
		super();
	}
	
	
	public Person(String job, String salary) {
		super();
		this.job = job;
		this.salary = salary;
	}


	public Person(String name, float weight, int age, String job, String salary) {
		super(name, weight, age);
		this.job = job;
		this.salary = salary;
	}

//****/////
	
	
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}


	public String toString() {
		return "Person [job=" + job + ", salary=" + salary + ", getJob()="
				+ getJob() + ", getSalary()=" + getSalary() + ", getName()="
				+ getName() + ", getWeight()=" + getWeight() + ", getAge()="
				+ getAge() + "]";
	}




}

class Child extends HierarchyInheritance{
	
	private String education;
	private String collegeName;
	
	//** Constructors  **//
	
	public Child() {
		super();
	}
	public Child(String education, String collegeName) {
		super();
		this.education = education;
		this.collegeName = collegeName;
	}
	public Child(String name, float weight, int age, String education,
			String collegeName) {
		super(name, weight, age);
		this.education = education;
		this.collegeName = collegeName;
	}
	/****/
	
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String toString() {
		return "child [education=" + education + ", collegeName=" + collegeName
				+ ", getEducation()=" + getEducation() + ", getCollegeName()="
				+ getCollegeName() + ", getName()=" + getName()
				+ ", getWeight()=" + getWeight() + ", getAge()=" + getAge()
				+ "]";
	}
	
	

	
	
}
