package inheritanceInJava;


//*** Multi-level inheritance**/

/*>> Multilevel_inheritance>> Student Class >> Engg_student*/


public class Multilevel_inheritance {
	
	private int age;
	private String name;
	
	//** Constructor **//
	
	public Multilevel_inheritance() {
		super();
		// TODO Auto-generated constructor stub
	}

	//** Constructor  with Arguments**//
	
	public Multilevel_inheritance(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	//*** getter Setter****///
	
	public int getAge() {
		return age;
	}
	public void setAge(int x) {
		this.age = x;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return "Multilevel_inheritance [age=" + age + ", name=" + name + "]";
	}
	
}
/* extend is "keyword" for multi-level Inheritance*/

class Student extends Multilevel_inheritance{
	 
	private float marks;
	private String type;
	
	
	//*** Constructor **//
	
	public Student(int age, String name, float marks, String type) {
		super(age, name);
		this.marks = marks;
		this.type = type;
	}

	public Student(float marks, String type) {
		super();
		this.marks = marks;
		this.type = type;
	}
	
	public Student() {
		super();
	}

	////****////
	
	
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String toString() {
		return "Student [marks=" + marks + ", type=" + type + ", getMarks()="
				+ getMarks() + ", getType()=" + getType() + "]";
	}
	
	
}


class Engg_student extends Student{
	
	private String collegeName;
	
	///**** constructor ***////
	
	public Engg_student(float marks, String type, String collegeName) {
		super(marks, type);
		this.collegeName = collegeName;
	}

	public Engg_student(int age, String name, float marks, String type,
			String collegeName) {
		super(age, name, marks, type);
		this.collegeName = collegeName;
	}

	public Engg_student() {
		super();
	}
	
	////*****/////

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String toString() {
		return "Engg_student [collegeName=" + collegeName
				+ ", getCollegeName()=" + getCollegeName() + ", getMarks()="
				+ getMarks() + ", getType()=" + getType() + "]";
	}
	
	
	
	
}

