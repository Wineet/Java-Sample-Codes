package inheritanceInJava;

public class InheritanceTester {

	public static void main(String[] args) {
		
		
//*>>>> Multi-LevelInheritance <<<*//
		
		/*Parent class Only Parent Class Members Are Accessible*/
		
		Multilevel_inheritance obj1= new Multilevel_inheritance(21, "vinit");
		
		//** Child 1 Level inheritance  parent and itself data member are accessable**//
		Student obj2 = new Student(22,"Vivek", 123f, "Student");
		
		//** 2 level inheritance child parent and super parent all data members are acc.**//
		
		Engg_student obj3 = new Engg_student(24, "Asmuth", 54, "Engg_Student", "MIT");
	
		System.out.println(obj1.toString());
		System.out.println(obj2.toString());
		System.out.println(obj3.toString());
		
		System.out.println();
		System.out.println();
		
		
		// Hierarchy Inheritance Two Child From One Parent  
		
		HierarchyInheritance obj4 = new HierarchyInheritance("Asmuth", 129f, 12);
		Person obj5 = new Person("Chiku", 40f, 12, "Analyst", "30000");
		Child  obj6 = new Child("Vinit", 21f, 12, "Engg.", "MIT");
		
		/* By default ToString Function Is Called*/
		
		System.out.println(obj4);		
		System.out.println(obj5);
		System.out.println(obj6);

		
		
		
		
		

	}

}
